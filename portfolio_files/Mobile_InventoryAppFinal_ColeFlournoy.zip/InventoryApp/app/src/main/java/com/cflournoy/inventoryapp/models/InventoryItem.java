package com.cflournoy.inventoryapp.models;

public class InventoryItem {
    private int id;
    private String name;
    private int count;
    private String description;

    // Constructor to initialize a FoodItem object
    public InventoryItem(int id, String name, int count, String description) {
        this.id = id;
        this.name = name;
        this.count = count;
        this.description = description;
    }

    // Getters
    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public int getCount() {
        return count;
    }
    public String getDescription() {
        return description;
    }

}
