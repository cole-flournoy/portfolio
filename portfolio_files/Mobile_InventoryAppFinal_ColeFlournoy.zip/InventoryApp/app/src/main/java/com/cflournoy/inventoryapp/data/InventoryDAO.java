package com.cflournoy.inventoryapp.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.cflournoy.inventoryapp.InventoryApplication;
import com.cflournoy.inventoryapp.models.InventoryItem;

import java.util.ArrayList;
import java.util.List;

public class InventoryDAO {

    private AppDatabase db;

    public InventoryDAO(Context context) {
        // Access db instance
        db = InventoryApplication.getDatabase();
    }

    // Create new inventory item
    public boolean addInventoryItem(String name, int count, String description) {
        SQLiteDatabase database = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("count", count);
        values.put("description", description);

        long newRowId = database.insert("inventory", null, values);
        database.close();
        // Insert returns -1 if unsuccessful
        return newRowId != -1;
    }

    // Read inventory item by id
    public InventoryItem getInventoryItemById(int id) {
        SQLiteDatabase database = db.getReadableDatabase();
        String selection = "_id = ?";
        String[] selectionArgs = { String.valueOf(id) };

        Cursor cursor = database.query("inventory", null, selection, selectionArgs, null, null, null);
        InventoryItem item = null;
        if (cursor.moveToFirst()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
            int count = cursor.getInt(cursor.getColumnIndexOrThrow("count"));
            String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));
            item = new InventoryItem(id, name, count, description);
            cursor.close();
        }
        database.close();
        return item;
    }

    // Read all inventory items
    public List<InventoryItem> getAllInventoryItems() {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase database = db.getReadableDatabase();
        Cursor cursor = database.query("inventory", null, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("_id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                int count = cursor.getInt(cursor.getColumnIndexOrThrow("count"));
                String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));
                InventoryItem item = new InventoryItem(id, name, count, description);
                items.add(item);
            } while (cursor.moveToNext());
            cursor.close();
        }
        database.close();
        return items;
    }

    // Update inventory item
    public boolean updateInventoryItem(InventoryItem item) {
        SQLiteDatabase database = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", item.getName());
        values.put("count", item.getCount());
        values.put("description", item.getDescription());

        String whereClause = "_id = ?";
        String[] whereArgs = { String.valueOf(item.getId()) };

        int rowsUpdated = database.update("inventory", values, whereClause, whereArgs);
        database.close();
        return rowsUpdated > 0;
    }

    // Delete inventory item by id
    public boolean deleteInventoryItem(int id) {
        SQLiteDatabase database = db.getWritableDatabase();
        String whereClause = "_id = ?";
        String[] whereArgs = { String.valueOf(id) };

        int rowsDeleted = database.delete("inventory", whereClause, whereArgs);
        database.close();
        return rowsDeleted > 0;
    }
}