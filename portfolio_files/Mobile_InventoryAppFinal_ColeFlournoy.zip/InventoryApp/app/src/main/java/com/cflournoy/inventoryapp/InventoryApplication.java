package com.cflournoy.inventoryapp;

import android.app.Application;

import com.cflournoy.inventoryapp.data.AppDatabase;

// Application subclass for database singleton
public class InventoryApplication extends Application {
    private static AppDatabase database;

    @Override
    public void onCreate() {
        super.onCreate();
        database = new AppDatabase(this);
    }

    public static AppDatabase getDatabase() {
        return database;
    }
}