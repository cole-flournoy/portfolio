package com.cflournoy.inventoryapp.models;

public class User {
    private int id;
    private String username;
    private String password;

    // Constructor to initialize a User object
    public User(int id, String username, String password) {
        this.id = id;
        this.username = username;
        this.password = password;
    }

    // Getters
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

}
