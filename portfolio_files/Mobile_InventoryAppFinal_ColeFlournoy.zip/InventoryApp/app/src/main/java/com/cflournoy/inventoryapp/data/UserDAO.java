package com.cflournoy.inventoryapp.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.cflournoy.inventoryapp.InventoryApplication;
import com.cflournoy.inventoryapp.models.User;

public class UserDAO {

    private AppDatabase db;

    public UserDAO(Context context) {
        db = InventoryApplication.getDatabase();
    }

    // Login existing user
    public boolean loginUser(String username, String password) {
        // Get a readable database
        SQLiteDatabase database = db.getReadableDatabase();

        // Define the columns to retrieve and the selection criteria
        String[] columns = {"password"};
        String selection = "username = ?";
        String[] selectionArgs = { username };

        // Query the database
        Cursor cursor = database.query("users", columns, selection, selectionArgs, null, null, null);

        boolean loginSuccessful = false;
        if (cursor.moveToFirst()) {
            // Get the stored password
            String storedPassword = cursor.getString(cursor.getColumnIndexOrThrow("password"));
            loginSuccessful = storedPassword.equals(password);
        }

        // Close resources
        cursor.close();
        database.close();

        return loginSuccessful;
    }

    // Create new user
    public boolean addUser(String username, String password) {
        // Get writable database
        SQLiteDatabase database = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long newRowId = database.insert("users", null, values);
        database.close();
        // If newRowId is -1, the insertion failed
        return newRowId != -1;
    }

    // Helper to check for existing users
    public User getUserByUsername(String username) {
        SQLiteDatabase database = db.getReadableDatabase();
        String query = "SELECT * FROM users WHERE username = ?";
        Cursor cursor = database.rawQuery(query, new String[]{username});

        User user = null;
        if (cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("_id"));
            String storedUsername = cursor.getString(cursor.getColumnIndexOrThrow("username"));
            String storedPassword = cursor.getString(cursor.getColumnIndexOrThrow("password"));
            user = new User(id, storedUsername, storedPassword);
        }
        cursor.close();
        database.close();
        return user;
    }
}