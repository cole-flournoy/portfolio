package com.cflournoy.inventoryapp;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.Manifest;

import com.cflournoy.inventoryapp.data.InventoryDAO;
import com.cflournoy.inventoryapp.models.InventoryItem;

import java.util.List;

public class InventoryTableActivity extends AppCompatActivity {
    private EditText nameEditText, countEditText, descriptionEditText;
    private InventoryDAO inventoryDAO = new InventoryDAO(this);
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory_table);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.inventoryTable), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Check for SMS permissions if not already done
        promptSMSPermission();

        // Fetch inventory from DB
        List<InventoryItem> inventoryList = inventoryDAO.getAllInventoryItems();

        TableLayout tableLayout = findViewById(R.id.inventoryTableLayout);

        // Iterate over inventory list
        for (InventoryItem item : inventoryList) {
            // Create a new TableRow
            TableRow tableRow = new TableRow(this);

            // Set layout parameters for the row
            TableRow.LayoutParams rowParams = new TableRow.LayoutParams(
                    TableRow.LayoutParams.MATCH_PARENT,
                    TableRow.LayoutParams.WRAP_CONTENT);
            tableRow.setLayoutParams(rowParams);

            // Create TextViews to display the data for the row
            TextView idEntry = new TextView(this);
            idEntry.setText(String.valueOf(item.getId()));
            idEntry.setTextSize(14);
            idEntry.setPadding(16, 16, 16, 16);

            TextView nameEntry = new TextView(this);
            nameEntry.setText(item.getName());
            nameEntry.setTextSize(14);
            nameEntry.setPadding(16, 16, 16, 16);
            nameEntry.setEllipsize(TextUtils.TruncateAt.END);

            TextView countEntry = new TextView(this);
            countEntry.setText(String.valueOf(item.getCount()));
            countEntry.setTextSize(14);
            countEntry.setPadding(16, 16, 16, 16);

            TextView descriptionEntry = new TextView(this);
            descriptionEntry.setText(item.getDescription());
            descriptionEntry.setTextSize(14);
            descriptionEntry.setPadding(16, 16, 16, 16);
            descriptionEntry.setEllipsize(TextUtils.TruncateAt.END);

            // Create a layout to hold the action buttons
            LinearLayout actionsLayout = new LinearLayout(this);
            actionsLayout.setOrientation(LinearLayout.HORIZONTAL);

            // Create the edit icon button (pencil)
            ImageButton editButton = new ImageButton(this);
            editButton.setImageResource(R.drawable.baseline_edit_24);
            editButton.setBackgroundColor(Color.TRANSPARENT);

            // Edit button onClick callback
            editButton.setOnClickListener(view -> {
                // Create an intent to launch ItemEditActivity
                Intent intent = new Intent(InventoryTableActivity.this, EditItemActivity.class);
                // Attach item details to extras
                intent.putExtra("itemId", item.getId());
                intent.putExtra("itemName", item.getName());
                intent.putExtra("itemCount", item.getCount());
                intent.putExtra("itemDescription", item.getDescription());
                // Start the ItemEditActivity
                startActivity(intent);
            });

            // Create the delete icon button (trashcan)
            ImageButton deleteButton = new ImageButton(this);
            deleteButton.setImageResource(R.drawable.trash_icon);
            deleteButton.setBackgroundColor(Color.TRANSPARENT);

            // Delete button onClick callback
            deleteButton.setOnClickListener(view -> {
                // Show a confirmation dialog
                new AlertDialog.Builder(InventoryTableActivity.this)
                        .setTitle("Confirm Deletion")
                        .setMessage("Are you sure you want to delete '" + item.getName() + "' from your inventory?")
                        .setPositiveButton("Yes", (dialog, which) -> {
                            // User confirmed, so delete the item from the database
                            boolean deleted = inventoryDAO.deleteInventoryItem(item.getId());
                            if (deleted) {
                                Toast.makeText(InventoryTableActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
                                // Refresh the activity so the deleted item is removed from the table.
                                finish();
                                startActivity(getIntent());
                            } else {
                                Toast.makeText(InventoryTableActivity.this, "Could not delete item", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("No", null)
                        .show();
            });

            // Add the two buttons to the actions layout
            actionsLayout.addView(editButton);
            actionsLayout.addView(deleteButton);

            // Add all views to the TableRow
            tableRow.addView(idEntry);
            tableRow.addView(nameEntry);
            tableRow.addView(countEntry);
            tableRow.addView(descriptionEntry);
            tableRow.addView(actionsLayout);

            // Add the TableRow to the TableLayout
            tableLayout.addView(tableRow);

        }

        // Get the relevant UI elements for creation
        nameEditText = findViewById(R.id.createName);
        countEditText = findViewById(R.id.createCount);
        descriptionEditText = findViewById(R.id.createDescription);
    }

    // Callback to create a new inventory item
    public void addItemButtonClick(View view) {
        String name = nameEditText.getText().toString().trim();
        String countStr = countEditText.getText().toString().trim();
        String description = descriptionEditText.getText().toString().trim();

        if (name.isEmpty() || countStr.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        int count;
        try {
            count = Integer.parseInt(countStr);
        } catch (NumberFormatException e) {
            // Handle the error (e.g., show a toast message)
            Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Use inventoryDAO to add the inventory item
        boolean itemCreated = inventoryDAO.addInventoryItem(name, count, description);

        if (itemCreated) {
            Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show();
            finish();
            startActivity(getIntent());
        } else {
            Toast.makeText(this, "There was an error saving your new item in the database", Toast.LENGTH_SHORT).show();
        }
    }

    // Prompts for SMS permission
    private void promptSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission not explicitly granted, check if the user has been asked
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                // Permission has not been requested yet
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_REQUEST_CODE);
            }
        }
    }
}