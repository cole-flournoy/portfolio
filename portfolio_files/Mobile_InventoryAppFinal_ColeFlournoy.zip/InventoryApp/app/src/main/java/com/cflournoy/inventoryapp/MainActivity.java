package com.cflournoy.inventoryapp;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.cflournoy.inventoryapp.data.UserDAO;
import com.cflournoy.inventoryapp.models.User;

// Login screen is the default activity
public class MainActivity extends AppCompatActivity {
    private EditText usernameEditText, passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Get the relevant UI elements
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
    }

    // Login click callback
    public void loginButtonClick(View view) {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }
        // TODO: Disable buttons if empty fields

        // Use UserDAO to verify the credentials
        UserDAO userDAO = new UserDAO(this);
        boolean isValid = userDAO.loginUser(username, password);

        if (isValid) {
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
            // Navigate to InventoryTableActivity
            Intent intent = new Intent(MainActivity.this, InventoryTableActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Invalid credentials. Please try again or sign up if you are a new user.", Toast.LENGTH_SHORT).show();
        }
    }

    // Sign up click callback
    public void signUpButtonClick(View view) {
        // Retrieve input values from the EditText fields
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString();

        if(username.isEmpty() || password.isEmpty()){
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        UserDAO userDAO = new UserDAO(this);
        User existingUser = userDAO.getUserByUsername(username);

        if (existingUser != null) {
            // User already exists, so check if the password matches
            if (existingUser.getPassword().equals(password)) {
                // Password correct. Log the user in
                Toast.makeText(this, "Existing user found. Login successful", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, InventoryTableActivity.class);
                startActivity(intent);
            } else {
                // Password does not match
                Toast.makeText(this, "Username is already taken", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Username doesn't exist, so create a new user
            boolean result = userDAO.addUser(username, password);
            if(!result) {
                Toast.makeText(this, "Error creating user", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Sign-up successful", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, InventoryTableActivity.class);
                startActivity(intent);
            }
        }
    }
}