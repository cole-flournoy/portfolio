package com.cflournoy.inventoryapp;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.cflournoy.inventoryapp.data.InventoryDAO;
import com.cflournoy.inventoryapp.models.InventoryItem;

public class EditItemActivity extends AppCompatActivity {
    private TextView idTextView;
    private EditText nameEditText, countEditText, descriptionEditText;
    private InventoryDAO inventoryDAO;
    private int itemId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_item);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.editItemLayout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize the views
        idTextView = findViewById(R.id.itemId);
        nameEditText = findViewById(R.id.editName);
        countEditText = findViewById(R.id.editCount);
        descriptionEditText = findViewById(R.id.editDescription);

        // Initialize the DAO
        inventoryDAO = new InventoryDAO(this);

        // Get the inventory item details
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            itemId = extras.getInt("itemId");
            String itemName = extras.getString("itemName");
            int itemCount = extras.getInt("itemCount");
            String itemDescription = extras.getString("itemDescription");

            // Populate the form fields with the current item details
            idTextView.setText("ID: " + itemId);
            nameEditText.setText(itemName);
            countEditText.setText(String.valueOf(itemCount));
            descriptionEditText.setText(itemDescription);
        } else {
            Toast.makeText(this, "Error loading item details", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private boolean SMSPermissionGranted (){
        // User has already been explicitly asked
        return ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    // Callback to save item info
    public void updateButtonClick(View view) {
        String updatedName = nameEditText.getText().toString().trim();
        String countStr = countEditText.getText().toString().trim();
        String updatedDescription = descriptionEditText.getText().toString().trim();

        if (updatedName.isEmpty() || countStr.isEmpty() || updatedDescription.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        int updatedCount;
        try {
            updatedCount = Integer.parseInt(countStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid number for count", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a new InventoryItem with the updated values
        InventoryItem updatedItem = new InventoryItem(itemId, updatedName, updatedCount, updatedDescription);

        // Attempt to update the record in the database
        boolean success = inventoryDAO.updateInventoryItem(updatedItem);
        if (success) {
            // Check for low inventory
            if (updatedCount < 3 && SMSPermissionGranted()){
                // Send SMS message (commented out because there is no phone number)
                // String phoneNumber = "1234567890";
                // String message = "Inventory for " + updatedName + " is low (" + countStr + " units)";
                // try {
                //    SmsManager smsManager = SmsManager.getDefault();
                //    smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                // } catch (Exception e) {
                //    e.printStackTrace();
                Toast.makeText(this, "USER WILL RECEIVE AN SMS MESSAGE ABOUT LOW INVENTORY", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Item updated successfully", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Error updating item", Toast.LENGTH_SHORT).show();
        }
    }

    // Callback to return to previous screen
    public void backButtonClick(View view) {
        // Navigate to InventoryTableActivity
        Intent intent = new Intent(EditItemActivity.this, InventoryTableActivity.class);
        startActivity(intent);
    }
}
